import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
public class Main {
    static Scanner teclado = new Scanner(System.in);
    static Random valorAleatorio = new Random();
    static int quantidadeReservas = 0, maxReservas = 10;

    public static void main(String[] args) {
        boolean codigoEncontrado = false;
        int codigo;
        ArrayList <Integer> codigos = new ArrayList<>();
        ArrayList <Boolean> pendencias = new ArrayList<>();

        // conjunto de codigos aleatorios
        for (int i = 0; i < 10; i++){
            codigos.add(geraAleatorio());
        }

        for(Integer lista : codigos){
            System.out.println("Códigos #"+ lista);
        }
        //conjunto de pendencias
        for(int i = 0; i < 10; i++){
            if(i % 2 == 0){
                pendencias.add(true);

            }else{

                pendencias.add(false);

            }
        }

        System.out.println();
        System.out.println(">>>> Informe o seu código <<<<");
        codigo = teclado.nextInt();

        for(Integer busca : codigos){
            if(busca == codigo){
                codigoEncontrado = true;
            }
        }

        if(codigoEncontrado == true){
            for(int i = 0; i < 10; i++){
                if(codigo){
                    System.out.println("Reserva negada por motivo de pendências!!!");

                }else{

                    registraReserva();

                }
            }

        }else{
            System.out.println();
            System.out.println("Reserva negada por motivo de falta de cadastro!");
        }


    }
    public static void registraReserva(){
        if(quantidadeReservas < maxReservas){
            quantidadeReservas++;

        }else {

            System.out.println("Restaurante lotado!!");
        }
    }

    public static int geraAleatorio(){
        int numeroAleatorio;

        numeroAleatorio = valorAleatorio.nextInt(0, 9999);

        return numeroAleatorio;
    }
}